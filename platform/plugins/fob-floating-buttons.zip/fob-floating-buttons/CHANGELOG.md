# Changelog

All notable changes to `fob-floatting-buttons` will be documented in this file

## 1.0.0 - 2024-01-20

- First release 🥳
