<?php

return [
    'menu_name' => 'Cáo Phó',
];