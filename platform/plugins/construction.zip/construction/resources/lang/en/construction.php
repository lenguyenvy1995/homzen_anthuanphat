<?php

return [
    'name' => 'Constructions',
    'create' => 'New construction',
];
